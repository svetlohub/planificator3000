# Reporter Service

Deterministic weekly report generator. No AI, no LLM — pure aggregation.

## Location

`apps/api/app/services/reporter.py`

## Input / Output

```
Input:  WeeklyPlanResult
Output: WeeklyReport
```

## WeeklyReport Fields

| Field | Type | Source |
|---|---|---|
| `week_ref` | `str` | Copied from `WeeklyPlanResult.week_ref` |
| `active_tasks_count` | `int` | `len(result.scheduled_tasks)` |
| `completed_tasks_count` | `int` | Always `0` at generation time; filled externally |
| `summary_lines` | `list[str]` | Deterministic bullet list (see below) |
| `total_referenced_tasks_count` | `int` | `active + completed` |
| `has_activity` | `bool` | `active_tasks_count > 0` |

## Summary Lines Algorithm

```
1. "Всего задач: N"
2. "Запланировано: N"
3. "В бэклог: N"
4. "Плановые часы: N.Nч"
5. "Ёмкость команды: N.Nч"
6. "Средняя загрузка: N.N%"     ← only if team present
7. "  Name: N.N%"               ← one line per member, sorted by name
8. "Часы бэклога: N.Nч"         ← only if backlog non-empty
```

## Utilization Calculation

```
utilization(member) = allocated_hours / available_hours × 100
```

If `available_hours == 0` → utilization = 0%.

## Top Categories

Built from `Counter(task.task_type for task in scheduled_tasks)`.
Returns up to 5 most frequent types.
