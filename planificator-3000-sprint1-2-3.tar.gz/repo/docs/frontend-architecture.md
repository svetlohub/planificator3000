# Frontend Architecture

## Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript strict |
| Styling | Tailwind CSS v4 |
| Animations | Framer Motion |
| Charts | Recharts |
| Testing | Vitest + Testing Library |
| State | React `useState` (no external store) |
| Data fetching | native `fetch` via typed API client |

## Directory Structure

```
apps/web/
├── app/                         Next.js App Router pages
│   ├── layout.tsx               Root layout — sidebar + dark theme
│   ├── page.tsx                 Redirect → /dashboard
│   ├── globals.css              Design tokens, glass utilities
│   ├── dashboard/
│   │   ├── page.tsx             Run pipeline, stat cards, charts
│   │   ├── loading.tsx          Skeleton
│   │   └── error.tsx            Error boundary
│   ├── report/page.tsx          WeeklyReport viewer
│   ├── team/page.tsx            Allocations table + per-member breakdown
│   ├── backlog/page.tsx         Backlog grouped by week_ref
│   └── settings/page.tsx        Health status, env info (read-only)
│
├── src/
│   ├── lib/api/
│   │   ├── client.ts            Base apiFetch with ApiError
│   │   ├── types.ts             TypeScript contracts mirroring Pydantic models
│   │   ├── plans.ts             generatePlan, getCurrentPlan, exportPlan
│   │   └── report.ts            getCurrentReport, getHealth
│   │
│   └── components/
│       ├── sidebar.tsx          Fixed navigation sidebar
│       ├── ui/
│       │   ├── stat-card.tsx    Metric card with accent color + icon
│       │   ├── feedback.tsx     Badge, LoadingState, EmptyState, ErrorState
│       │   ├── data-table.tsx   Generic typed table
│       │   └── utils.ts         cn() helper
│       └── charts/
│           ├── capacity-chart.tsx   Stacked bar (allocated vs remaining)
│           └── workload-chart.tsx   Pie chart by task_type
│
└── __tests__/
    ├── dashboard.test.tsx
    ├── report.test.tsx
    └── backlog.test.tsx
```

## Page States

Every page implements three states:

| State | Component |
|---|---|
| Loading | `<LoadingState>` |
| Empty / Idle | `<EmptyState>` |
| Error | `<ErrorState onRetry={...}>` |

## API Client

```typescript
// All API calls go through apiFetch
const result = await apiFetch<WeeklyPlanResult>("/plans/generate?week_ref=2026-W25");
```

`ApiError` is thrown when `res.ok === false`.
Pages catch it and display via `<ErrorState>`.

## Design System

Dark theme only. CSS variables defined in `packages/ui/src/styles.css`
and consumed via Tailwind v4 `@theme`.

| Token | Value |
|---|---|
| `--color-background` | `#0f172a` |
| `--color-primary` | `#19aef9` |
| `--color-accent-foreground` | `#ff9839` |
| `--color-success` | `#22c55e` |

Glass utility classes: `.glass`, `.glass-strong`
Gradient text: `.gradient-text`

## Environment Variables

| Variable | Required | Default |
|---|---|---|
| `NEXT_PUBLIC_API_URL` | Yes (prod) | `http://localhost:8000` |
