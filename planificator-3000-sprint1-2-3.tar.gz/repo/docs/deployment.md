# Deployment Guide

## Architecture

| Component | Platform | Notes |
|---|---|---|
| Frontend | Vercel | Auto-deploy from `main` branch |
| Backend | Railway | Docker-based, always-on |
| Database | None | Google Sheets only |
| Secrets | Platform env vars | Never committed to repo |

---

## Backend — Railway

### 1. Create project

```bash
# Install Railway CLI
npm install -g @railway/cli
railway login
railway init
```

### 2. Set environment variables in Railway dashboard

```
APP_ENV=production
GOOGLE_SHEET_ID=<your-sheet-id>
GOOGLE_SERVICE_ACCOUNT_JSON=<full-json-as-single-line>
CORS_ORIGINS=https://your-vercel-app.vercel.app
```

### 3. Deploy

Railway auto-detects the Dockerfile at `apps/api/Dockerfile`.

Root directory: `apps/api`

Start command (set in Railway):
```
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

### 4. Health check

Railway health check path: `/api/v1/health`

Expected response:
```json
{"status": "ok", "sheets_configured": true, "sheets_healthy": true}
```

---

## Frontend — Vercel

### 1. Import repository

Connect GitHub repo at vercel.com/new.

### 2. Configure project

| Setting | Value |
|---|---|
| Framework | Next.js |
| Root directory | `apps/web` |
| Build command | `pnpm build` |
| Install command | `pnpm install --frozen-lockfile` |

### 3. Set environment variables

```
NEXT_PUBLIC_API_URL=https://your-railway-app.railway.app
```

### 4. Deploy

Push to `main` → Vercel deploys automatically.

---

## Google Sheets Setup

### Required worksheets

| Worksheet | Purpose |
|---|---|
| `Monthly Plan` | Planned tasks for the month |
| `Completed Tasks` | Done / in-progress tasks |
| `Recurring Tasks` | Weekly recurring tasks |
| `Team Roster` | Team members + capacity |
| `Config` | `buffer_percent` and other settings |
| `Weekly Plan` | **Output** — written by export |
| `Backlog` | **Output** — written by export |
| `Team Allocation` | **Output** — written by export |
| `Weekly Report` | **Output** — written by export |

### Service Account

1. Create a Service Account in Google Cloud Console.
2. Grant it **Editor** access to the spreadsheet.
3. Download the JSON key.
4. Minify to a single line and set as `GOOGLE_SERVICE_ACCOUNT_JSON`.

### Config sheet format

| Key | Value |
|---|---|
| `buffer_percent` | `25` |

---

## Local Development

```bash
# Clone and install
git clone https://github.com/your-org/planificator-3000
pnpm install

# Backend
cp apps/api/.env.example apps/api/.env
# Fill in GOOGLE_SHEET_ID and GOOGLE_SERVICE_ACCOUNT_JSON
cd apps/api && uv sync && uv run uvicorn app.main:app --reload

# Frontend (new terminal)
cp apps/web/.env.example apps/web/.env.local
# NEXT_PUBLIC_API_URL=http://localhost:8000
pnpm dev
```

Open: http://localhost:3000

---

## Docker Compose (local full-stack)

```bash
# Create real .env files from examples
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env.local
# Fill in credentials

docker compose up --build
```

Frontend: http://localhost:3000
Backend:  http://localhost:8000/api/v1/health

---

## Troubleshooting

### `sheets_healthy: false`

- Verify `GOOGLE_SHEET_ID` is correct (from the URL: `/spreadsheets/d/<ID>/`).
- Verify the service account email has Editor access to the sheet.
- Verify `GOOGLE_SERVICE_ACCOUNT_JSON` is valid JSON (no line breaks).

### `503 Google Sheets integration is not configured`

- `APP_ENV` is not `local` but credentials are missing → set both env vars.

### CORS errors in browser

- Add your Vercel URL to `CORS_ORIGINS` on Railway.
- Format: `https://your-app.vercel.app` (no trailing slash).

### `ValidationError` on startup (non-local env)

- `GOOGLE_SHEET_ID` or `GOOGLE_SERVICE_ACCOUNT_JSON` not set.
- Check Railway environment variable dashboard.
