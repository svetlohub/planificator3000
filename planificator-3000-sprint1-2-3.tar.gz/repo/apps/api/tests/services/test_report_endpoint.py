"""Tests for GET /api/v1/report/current."""

from typing import Any
from fastapi.testclient import TestClient
from app.config import Settings
from app.connectors.sheets import SheetsRepository
from app.main import create_app

WEEK = "2026-W25"

_SETTINGS = Settings(
    app_env="local",
    google_sheet_id="sheet-test",
    google_service_account_json='{"type":"service_account"}',
)

_TEAM_ROW = {
    "Name": "Алиса",
    "Weekly Capacity Hours": "40",
    "Reserved Buffer Percent": "25",
    "Skills": "",
}


class _FakeClient:
    def __init__(self, data: dict[str, list[dict[str, Any]]]) -> None:
        self._data = data

    def read_records(self, ws: str) -> list[dict[str, Any]]:
        return self._data.get(ws, [])

    def health_check(self) -> bool:
        return True


def _make_client(**kwargs: list[dict]) -> TestClient:
    data = {
        _SETTINGS.google_worksheet_team_roster: kwargs.get("team", []),
        _SETTINGS.google_worksheet_monthly_plan: kwargs.get("monthly", []),
        _SETTINGS.google_worksheet_recurring_tasks: kwargs.get("recurring", []),
        _SETTINGS.google_worksheet_completed_tasks: kwargs.get("completed", []),
        _SETTINGS.google_worksheet_config: kwargs.get("config", []),
    }
    repo = SheetsRepository(client=_FakeClient(data), settings=_SETTINGS)
    app = create_app()
    app.state.sheets_repository = repo
    app.state.sheets_client = _FakeClient(data)
    return TestClient(app)


def test_report_endpoint_returns_200() -> None:
    response = _make_client().get(f"/api/v1/report/current?week_ref={WEEK}")
    assert response.status_code == 200


def test_report_has_week_ref() -> None:
    body = _make_client().get(f"/api/v1/report/current?week_ref={WEEK}").json()
    assert body["week_ref"] == WEEK


def test_report_has_summary_lines() -> None:
    body = _make_client(team=[_TEAM_ROW]).get(f"/api/v1/report/current?week_ref={WEEK}").json()
    assert "summary_lines" in body
    assert isinstance(body["summary_lines"], list)


def test_report_active_tasks_zero_with_empty_sheets() -> None:
    body = _make_client().get(f"/api/v1/report/current?week_ref={WEEK}").json()
    assert body["active_tasks_count"] == 0


def test_report_returns_503_without_repository() -> None:
    app = create_app()
    app.state.sheets_repository = None
    client = TestClient(app, raise_server_exceptions=False)
    assert client.get(f"/api/v1/report/current?week_ref={WEEK}").status_code == 503
