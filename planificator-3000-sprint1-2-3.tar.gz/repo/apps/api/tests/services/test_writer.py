"""Tests for SheetsWriter — verifies correct worksheet names and row shapes."""

from typing import Any
from unittest.mock import MagicMock, call

import pytest
from app.connectors.sheets.writer import (
    SheetsWriter,
    _WS_BACKLOG,
    _WS_TEAM_ALLOCATION,
    _WS_WEEKLY_PLAN,
    _WS_WEEKLY_REPORT,
)
from app.domain import Allocation, Capacity, Task, TaskSource, TaskStatus, WeeklyReport
from app.services.schemas import WeeklyPlanResult

WEEK = "2026-W25"


def _task(task_id: str, assignee: str = "Ivan") -> Task:
    return Task(
        task_id=task_id,
        title=f"Task {task_id}",
        source=TaskSource.MONTHLY,
        status=TaskStatus.PLANNED,
        owner="Ivan",
        assignee=assignee,
        estimate_hours=2.0,
        task_type="analysis",
        week_ref=WEEK,
    )


def _allocation(assignee: str, tasks: list[Task]) -> Allocation:
    return Allocation(
        assignee=assignee,
        tasks=tasks,
        allocated_hours=round(sum(t.estimate_hours for t in tasks), 10),
    )


def _capacity(name: str) -> Capacity:
    return Capacity(member_name=name, total_hours=40.0, buffer_hours=10.0, available_hours=30.0)


def _result(scheduled: list[Task] | None = None, backlog: list[Task] | None = None, allocations: list[Allocation] | None = None) -> WeeklyPlanResult:
    s = scheduled or []
    b = backlog or []
    a = allocations or []
    return WeeklyPlanResult(
        week_ref=WEEK,
        scheduled_tasks=s,
        backlog_tasks=b,
        allocations=a,
        team_capacity=[],
        total_capacity_hours=0.0,
        planned_hours=round(sum(t.estimate_hours for t in s), 10),
        backlog_hours=round(sum(t.estimate_hours for t in b), 10),
    )


def _report() -> WeeklyReport:
    return WeeklyReport(week_ref=WEEK, completed_tasks_count=0, active_tasks_count=2, summary_lines=["Всего задач: 2"])


def _mock_client() -> MagicMock:
    client = MagicMock()
    client.write_records = MagicMock()
    return client


# ─────────────────────────────── worksheet names


def test_write_plan_result_calls_four_worksheets() -> None:
    client = _mock_client()
    writer = SheetsWriter(client)
    writer.write_plan_result(_result(), _report())

    called_names = {c.args[0] for c in client.write_records.call_args_list}
    assert _WS_WEEKLY_PLAN in called_names
    assert _WS_BACKLOG in called_names
    assert _WS_TEAM_ALLOCATION in called_names
    assert _WS_WEEKLY_REPORT in called_names


def test_write_called_exactly_four_times() -> None:
    client = _mock_client()
    SheetsWriter(client).write_plan_result(_result(), _report())
    assert client.write_records.call_count == 4


# ─────────────────────────────── row shape: weekly plan


def test_weekly_plan_rows_have_task_id_column() -> None:
    client = _mock_client()
    t = _task("T1")
    SheetsWriter(client).write_plan_result(_result(scheduled=[t]), _report())

    plan_call = next(c for c in client.write_records.call_args_list if c.args[0] == _WS_WEEKLY_PLAN)
    rows: list[dict] = plan_call.args[1]
    assert rows[0]["Task ID"] == "T1"


def test_weekly_plan_rows_include_assignee() -> None:
    client = _mock_client()
    t = _task("T1", assignee="Maria")
    SheetsWriter(client).write_plan_result(_result(scheduled=[t]), _report())

    plan_call = next(c for c in client.write_records.call_args_list if c.args[0] == _WS_WEEKLY_PLAN)
    rows: list[dict] = plan_call.args[1]
    assert rows[0]["Assignee"] == "Maria"


# ─────────────────────────────── row shape: backlog


def test_backlog_rows_have_task_id_column() -> None:
    client = _mock_client()
    b = _task("B1")
    SheetsWriter(client).write_plan_result(_result(backlog=[b]), _report())

    backlog_call = next(c for c in client.write_records.call_args_list if c.args[0] == _WS_BACKLOG)
    rows: list[dict] = backlog_call.args[1]
    assert rows[0]["Task ID"] == "B1"


# ─────────────────────────────── idempotent: empty lists write empty records


def test_empty_result_writes_empty_records_to_all_sheets() -> None:
    client = _mock_client()
    SheetsWriter(client).write_plan_result(_result(), _report())

    for c in client.write_records.call_args_list:
        ws_name = c.args[0]
        rows = c.args[1]
        if ws_name in (_WS_WEEKLY_PLAN, _WS_BACKLOG, _WS_TEAM_ALLOCATION):
            assert rows == [], f"Expected empty rows for {ws_name}"


# ─────────────────────────────── allocation rows


def test_allocation_rows_have_assignee_column() -> None:
    client = _mock_client()
    t = _task("T1", assignee="Ivan")
    a = _allocation("Ivan", [t])
    SheetsWriter(client).write_plan_result(_result(scheduled=[t], allocations=[a]), _report())

    alloc_call = next(c for c in client.write_records.call_args_list if c.args[0] == _WS_TEAM_ALLOCATION)
    rows: list[dict] = alloc_call.args[1]
    assert rows[0]["Assignee"] == "Ivan"
    assert rows[0]["Task ID"] == "T1"
