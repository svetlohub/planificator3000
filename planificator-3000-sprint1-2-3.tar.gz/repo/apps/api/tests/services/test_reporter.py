"""Tests for ReporterService."""

import pytest
from app.domain import Allocation, Capacity, Task, TaskSource, TaskStatus
from app.services.reporter import ReporterService
from app.services.schemas import WeeklyPlanResult

WEEK = "2026-W25"


def _task(task_id: str, task_type: str = "analysis", estimate: float = 2.0, assignee: str = "Ivan") -> Task:
    return Task(
        task_id=task_id,
        title=f"Task {task_id}",
        source=TaskSource.MONTHLY,
        status=TaskStatus.PLANNED,
        owner="Ivan",
        assignee=assignee,
        estimate_hours=estimate,
        task_type=task_type,
        week_ref=WEEK,
    )


def _capacity(name: str, total: float, available: float) -> Capacity:
    return Capacity(
        member_name=name,
        total_hours=total,
        buffer_hours=round(total - available, 10),
        available_hours=available,
    )


def _allocation(assignee: str, tasks: list[Task]) -> Allocation:
    return Allocation(
        assignee=assignee,
        tasks=tasks,
        allocated_hours=round(sum(t.estimate_hours for t in tasks), 10),
    )


def _result(
    scheduled: list[Task] | None = None,
    backlog: list[Task] | None = None,
    capacities: list[Capacity] | None = None,
    allocations: list[Allocation] | None = None,
) -> WeeklyPlanResult:
    s = scheduled or []
    b = backlog or []
    c = capacities or []
    a = allocations or []
    return WeeklyPlanResult(
        week_ref=WEEK,
        scheduled_tasks=s,
        backlog_tasks=b,
        allocations=a,
        team_capacity=c,
        total_capacity_hours=round(sum(cap.available_hours for cap in c), 10),
        planned_hours=round(sum(t.estimate_hours for t in s), 10),
        backlog_hours=round(sum(t.estimate_hours for t in b), 10),
    )


# ─────────────────────────────── WeeklyReport fields


def test_report_week_ref_matches_result() -> None:
    report = ReporterService().build_report(_result())
    assert report.week_ref == WEEK


def test_report_active_tasks_count_equals_scheduled() -> None:
    tasks = [_task("T1"), _task("T2")]
    report = ReporterService().build_report(_result(scheduled=tasks))
    assert report.active_tasks_count == 2


def test_report_completed_tasks_count_zero_by_default() -> None:
    report = ReporterService().build_report(_result())
    assert report.completed_tasks_count == 0


def test_report_summary_lines_not_empty() -> None:
    tasks = [_task("T1"), _task("T2")]
    report = ReporterService().build_report(_result(scheduled=tasks))
    assert len(report.summary_lines) > 0


def test_report_summary_contains_planned_count() -> None:
    tasks = [_task("T1"), _task("T2")]
    report = ReporterService().build_report(_result(scheduled=tasks))
    combined = "\n".join(report.summary_lines)
    assert "2" in combined


# ─────────────────────────────── utilization


def test_utilization_line_in_summary_when_team_present() -> None:
    t1 = _task("T1", assignee="Ivan")
    cap = _capacity("Ivan", 40.0, 30.0)
    alloc = _allocation("Ivan", [t1])
    report = ReporterService().build_report(_result(scheduled=[t1], capacities=[cap], allocations=[alloc]))
    combined = "\n".join(report.summary_lines)
    assert "Ivan" in combined


def test_zero_capacity_member_gets_zero_utilization() -> None:
    cap = _capacity("Ghost", 0.0, 0.0)
    report = ReporterService().build_report(_result(capacities=[cap]))
    # Should not crash; utilization = 0%
    combined = "\n".join(report.summary_lines)
    assert "Ghost" in combined


# ─────────────────────────────── top categories


def test_top_categories_most_frequent_first() -> None:
    tasks = [
        _task("T1", task_type="meeting"),
        _task("T2", task_type="meeting"),
        _task("T3", task_type="analysis"),
    ]
    reporter = ReporterService()
    categories = reporter._top_categories(_result(scheduled=tasks))
    assert categories[0] == "meeting"


def test_top_categories_empty_for_no_tasks() -> None:
    categories = ReporterService()._top_categories(_result())
    assert categories == []


# ─────────────────────────────── summary lines uniqueness (domain invariant)


def test_summary_lines_are_unique() -> None:
    report = ReporterService().build_report(_result())
    assert len(report.summary_lines) == len(set(report.summary_lines))


# ─────────────────────────────── backlog summary


def test_backlog_hours_line_present_when_backlog_exists() -> None:
    b = [_task("B1", estimate=3.0), _task("B2", estimate=2.0)]
    report = ReporterService().build_report(_result(backlog=b))
    combined = "\n".join(report.summary_lines)
    assert "5.0" in combined or "5,0" in combined or "бэклог" in combined.lower()
