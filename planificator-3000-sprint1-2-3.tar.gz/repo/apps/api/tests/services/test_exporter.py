"""Tests for ExportService."""

from unittest.mock import MagicMock, patch

import pytest
from app.domain import Task, TaskSource, TaskStatus
from app.services.exporter import ExportResult, ExportService
from app.services.schemas import WeeklyPlanResult

WEEK = "2026-W25"


def _empty_result() -> WeeklyPlanResult:
    return WeeklyPlanResult(
        week_ref=WEEK,
        scheduled_tasks=[],
        backlog_tasks=[],
        allocations=[],
        team_capacity=[],
        total_capacity_hours=0.0,
        planned_hours=0.0,
        backlog_hours=0.0,
    )


def _mock_client() -> MagicMock:
    client = MagicMock()
    client.write_records = MagicMock()
    return client


# ─────────────────────────────── success path


def test_export_returns_success_true_on_happy_path() -> None:
    result = ExportService(_mock_client()).export(_empty_result())
    assert result.success is True
    assert result.exported is True


def test_export_result_week_ref_matches() -> None:
    result = ExportService(_mock_client()).export(_empty_result())
    assert result.week_ref == WEEK


def test_export_result_is_dataclass() -> None:
    result = ExportService(_mock_client()).export(_empty_result())
    assert isinstance(result, ExportResult)


def test_export_error_is_none_on_success() -> None:
    result = ExportService(_mock_client()).export(_empty_result())
    assert result.error is None


def test_export_counts_match_result() -> None:
    result = ExportService(_mock_client()).export(_empty_result())
    assert result.scheduled_tasks == 0
    assert result.backlog_tasks == 0


# ─────────────────────────────── failure path


def test_export_returns_success_false_when_writer_raises() -> None:
    client = _mock_client()
    client.write_records.side_effect = RuntimeError("sheets API down")

    result = ExportService(client).export(_empty_result())

    assert result.success is False
    assert result.exported is False
    assert result.error is not None
    assert "sheets API down" in result.error


def test_export_does_not_reraise_exceptions() -> None:
    """ExportService must swallow exceptions and return ExportResult."""
    client = _mock_client()
    client.write_records.side_effect = ConnectionError("network timeout")

    # should not raise
    result = ExportService(client).export(_empty_result())
    assert result.success is False


# ─────────────────────────────── endpoint integration


def test_export_endpoint_returns_200(monkeypatch: pytest.MonkeyPatch) -> None:
    """POST /plans/export returns 200 with success=true when Sheets configured."""
    from typing import Any
    from fastapi.testclient import TestClient
    from app.config import Settings
    from app.connectors.sheets import SheetsRepository
    from app.main import create_app

    settings = Settings(
        app_env="local",
        google_sheet_id="sheet-test",
        google_service_account_json='{"type":"service_account"}',
    )

    class _FakeClient:
        def read_records(self, _: str) -> list[dict[str, Any]]:
            return []
        def write_records(self, _: str, __: list) -> None:
            pass
        def health_check(self) -> bool:
            return True

    app = create_app()
    fake_client = _FakeClient()
    app.state.sheets_repository = SheetsRepository(client=fake_client, settings=settings)
    app.state.sheets_client = fake_client  # type: ignore[assignment]

    client = TestClient(app)
    response = client.post("/api/v1/plans/export?week_ref=2026-W25")

    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["exported"] is True


def test_export_endpoint_returns_503_without_credentials() -> None:
    from fastapi.testclient import TestClient
    from app.main import create_app

    app = create_app()
    app.state.sheets_repository = None
    app.state.sheets_client = None

    client = TestClient(app, raise_server_exceptions=False)
    response = client.post("/api/v1/plans/export?week_ref=2026-W25")

    assert response.status_code == 503
