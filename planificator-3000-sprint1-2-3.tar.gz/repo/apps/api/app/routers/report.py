"""Report router.

Endpoints
---------
GET /report/current — generate and return the current WeeklyReport
"""

from fastapi import APIRouter

from app.connectors.sheets import SheetsMapper
from app.dependencies import SheetsRepositoryDep
from app.domain import WeeklyReport
from app.services import PlanningOrchestrator, ReporterService

router = APIRouter(prefix="/report", tags=["report"])


@router.get("/current", response_model=WeeklyReport)
def get_current_report(
    repository: SheetsRepositoryDep,
    week_ref: str = "2026-W25",
) -> WeeklyReport:
    """
    Generate a fresh WeeklyReport from current Sheets data.

    Steps:
    1. Load all worksheets
    2. Run planning pipeline
    3. Build WeeklyReport from result
    4. Return (read-only, no writes)
    """
    mapper = SheetsMapper()
    monthly_tasks = mapper.monthly_plan_to_domain_tasks(repository.load_monthly_plan())
    completed_tasks = mapper.completed_tasks_to_domain(repository.load_completed_tasks())
    recurring_tasks = mapper.recurring_tasks_to_domain(repository.load_recurring_tasks())
    team_members = mapper.team_roster_to_domain(repository.load_team_roster())
    config_rows = repository.load_config()

    result = PlanningOrchestrator().generate_weekly_plan(
        week_ref=week_ref,
        monthly_tasks=monthly_tasks,
        completed_tasks=completed_tasks,
        recurring_tasks=recurring_tasks,
        team_members=team_members,
        config_rows=config_rows,
    )

    return ReporterService().build_report(result)
