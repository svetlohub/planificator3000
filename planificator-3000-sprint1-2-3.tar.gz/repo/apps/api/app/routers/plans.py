"""Plans router.

Endpoints
---------
GET  /plans          — stub list
GET  /plans/current  — raw Sheets data as domain objects (Sprint 1)
GET  /plans/generate — full planning cycle via PlanningOrchestrator (Sprint 2)
POST /plans/export   — generate + report + write to Sheets (Sprint 3)
"""

from fastapi import APIRouter
from pydantic import BaseModel

from app.connectors.sheets import SheetsMapper
from app.dependencies import SettingsDep, SheetsClientDep, SheetsRepositoryDep
from app.domain import Task, TeamMember
from app.schemas import CurrentPlanResponse, Plan
from app.services import ExportResult, ExportService, PlanningOrchestrator, WeeklyPlanResult

router = APIRouter(prefix="/plans", tags=["plans"])


class ExportResponse(BaseModel):
    success: bool
    exported: bool
    week_ref: str
    scheduled_tasks: int
    backlog_tasks: int
    error: str | None = None


def _load_and_plan(
    repository: SheetsRepositoryDep,
    week_ref: str,
) -> WeeklyPlanResult:
    """Shared helper: load from Sheets → run orchestrator → return result."""
    mapper = SheetsMapper()
    monthly_tasks = mapper.monthly_plan_to_domain_tasks(repository.load_monthly_plan())
    completed_tasks = mapper.completed_tasks_to_domain(repository.load_completed_tasks())
    recurring_tasks = mapper.recurring_tasks_to_domain(repository.load_recurring_tasks())
    team_members = mapper.team_roster_to_domain(repository.load_team_roster())
    config_rows = repository.load_config()

    return PlanningOrchestrator().generate_weekly_plan(
        week_ref=week_ref,
        monthly_tasks=monthly_tasks,
        completed_tasks=completed_tasks,
        recurring_tasks=recurring_tasks,
        team_members=team_members,
        config_rows=config_rows,
    )


@router.get("", response_model=list[Plan])
def list_plans() -> list[Plan]:
    return [
        Plan(title="Синхронизировать стратегию продукта", status="active"),
        Plan(title="Запустить первый production-инкремент", status="draft"),
    ]


@router.get("/current", response_model=CurrentPlanResponse)
def get_current_plan(
    repository: SheetsRepositoryDep,
    settings: SettingsDep,
) -> CurrentPlanResponse:
    """Load raw tasks and team roster from Sheets; return domain objects."""
    mapper = SheetsMapper()
    monthly_rows = repository.load_monthly_plan()
    completed_rows = repository.load_completed_tasks()
    recurring_rows = repository.load_recurring_tasks()
    team_rows = repository.load_team_roster()

    tasks: list[Task] = [
        *mapper.monthly_plan_to_domain_tasks(monthly_rows),
        *mapper.completed_tasks_to_domain(completed_rows),
        *mapper.recurring_tasks_to_domain(recurring_rows),
    ]
    team: list[TeamMember] = mapper.team_roster_to_domain(team_rows)

    return CurrentPlanResponse(
        tasks=tasks,
        team=team,
        sheets_configured=settings.sheets_configured,
    )


@router.get("/generate", response_model=WeeklyPlanResult)
def generate_plan(
    repository: SheetsRepositoryDep,
    settings: SettingsDep,
    week_ref: str = "2026-W25",
) -> WeeklyPlanResult:
    """Execute the full planning pipeline and return a WeeklyPlanResult (read-only)."""
    return _load_and_plan(repository, week_ref)


@router.post("/export", response_model=ExportResponse)
def export_plan(
    repository: SheetsRepositoryDep,
    client: SheetsClientDep,
    week_ref: str = "2026-W25",
) -> ExportResponse:
    """
    Generate plan, build report, and write all results to Google Sheets.

    Flow:
        1. Load from Sheets
        2. Run PlanningOrchestrator
        3. Build WeeklyReport via ReporterService
        4. Write Weekly Plan, Backlog, Team Allocation, Weekly Report worksheets
        5. Return export status

    Idempotent: running twice produces identical worksheet contents.
    """
    result = _load_and_plan(repository, week_ref)
    export_result: ExportResult = ExportService(client).export(result)

    return ExportResponse(
        success=export_result.success,
        exported=export_result.exported,
        week_ref=export_result.week_ref,
        scheduled_tasks=export_result.scheduled_tasks,
        backlog_tasks=export_result.backlog_tasks,
        error=export_result.error,
    )
