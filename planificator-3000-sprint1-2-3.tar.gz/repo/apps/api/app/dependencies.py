from typing import Annotated

from fastapi import Depends, HTTPException, Request

from app.config import Settings, get_settings
from app.connectors.sheets import SheetsRepository
from app.connectors.sheets.client import GoogleSheetsClient


def get_sheets_repository(request: Request) -> SheetsRepository:
    """
    Retrieve the SheetsRepository stored in app.state.

    Raises 503 if the repository was not initialised (missing credentials).
    """
    repository: SheetsRepository | None = getattr(request.app.state, "sheets_repository", None)
    if repository is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Google Sheets integration is not configured. "
                "Set GOOGLE_SHEET_ID and GOOGLE_SERVICE_ACCOUNT_JSON."
            ),
        )
    return repository


def get_sheets_client(request: Request) -> GoogleSheetsClient:
    """
    Retrieve the GoogleSheetsClient stored in app.state.

    Raises 503 if the client was not initialised (missing credentials).
    """
    client: GoogleSheetsClient | None = getattr(request.app.state, "sheets_client", None)
    if client is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Google Sheets integration is not configured. "
                "Set GOOGLE_SHEET_ID and GOOGLE_SERVICE_ACCOUNT_JSON."
            ),
        )
    return client


SheetsRepositoryDep = Annotated[SheetsRepository, Depends(get_sheets_repository)]
SheetsClientDep = Annotated[GoogleSheetsClient, Depends(get_sheets_client)]
SettingsDep = Annotated[Settings, Depends(get_settings)]
