"""
SheetsWriter

Writes WeeklyPlanResult data back to Google Sheets.

Rules
-----
- All writes are idempotent: running twice produces identical sheet state.
- Each worksheet is fully replaced (clear + write) — no append-only behaviour.
- Missing worksheets cause SheetAccessError (surfaced by the client).
- Empty record sets clear the worksheet rather than writing a header-only row.
"""

from app.connectors.sheets.client import GoogleSheetsClient
from app.domain import Allocation, Capacity, Task
from app.domain.report import WeeklyReport
from app.services.schemas import WeeklyPlanResult

# Column names used as worksheet headers
_PLAN_HEADERS = ["Task ID", "Title", "Owner", "Assignee", "Estimate Hours", "Task Type", "Week", "Status"]
_BACKLOG_HEADERS = ["Task ID", "Title", "Owner", "Estimate Hours", "Task Type", "Week"]
_ALLOCATION_HEADERS = ["Assignee", "Task ID", "Title", "Estimate Hours", "Task Type"]
_REPORT_HEADERS = ["Week", "Metric", "Value"]

_WS_WEEKLY_PLAN = "Weekly Plan"
_WS_BACKLOG = "Backlog"
_WS_WEEKLY_REPORT = "Weekly Report"
_WS_TEAM_ALLOCATION = "Team Allocation"


def _task_to_plan_row(task: Task) -> dict[str, object]:
    return {
        "Task ID": task.task_id,
        "Title": task.title,
        "Owner": task.owner,
        "Assignee": task.assignee or "",
        "Estimate Hours": task.estimate_hours,
        "Task Type": task.task_type,
        "Week": task.week_ref,
        "Status": task.status.value,
    }


def _task_to_backlog_row(task: Task) -> dict[str, object]:
    return {
        "Task ID": task.task_id,
        "Title": task.title,
        "Owner": task.owner,
        "Estimate Hours": task.estimate_hours,
        "Task Type": task.task_type,
        "Week": task.week_ref,
    }


def _allocation_to_rows(allocation: Allocation) -> list[dict[str, object]]:
    return [
        {
            "Assignee": allocation.assignee,
            "Task ID": task.task_id,
            "Title": task.title,
            "Estimate Hours": task.estimate_hours,
            "Task Type": task.task_type,
        }
        for task in allocation.tasks
    ]


def _report_to_rows(report: WeeklyReport) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = [
        {"Week": report.week_ref, "Metric": "active_tasks", "Value": report.active_tasks_count},
        {"Week": report.week_ref, "Metric": "completed_tasks", "Value": report.completed_tasks_count},
        {"Week": report.week_ref, "Metric": "total_tasks", "Value": report.total_referenced_tasks_count},
    ]
    for line in report.summary_lines:
        rows.append({"Week": report.week_ref, "Metric": "summary", "Value": line})
    return rows


class SheetsWriter:
    """
    Idempotent Google Sheets writer for weekly plan outputs.

    Usage::

        writer = SheetsWriter(client)
        writer.write_plan_result(result, report)
    """

    def __init__(self, client: GoogleSheetsClient) -> None:
        self._client = client

    def write_plan_result(self, result: WeeklyPlanResult, report: WeeklyReport) -> None:
        """Write all four output worksheets atomically (best-effort per worksheet)."""
        self._write_weekly_plan(result.scheduled_tasks)
        self._write_backlog(result.backlog_tasks)
        self._write_allocations(result.allocations)
        self._write_report(report)

    # ---------------------------------------------------------------- private

    def _write_weekly_plan(self, tasks: list[Task]) -> None:
        rows = [_task_to_plan_row(t) for t in tasks]
        self._client.write_records(_WS_WEEKLY_PLAN, rows)

    def _write_backlog(self, tasks: list[Task]) -> None:
        rows = [_task_to_backlog_row(t) for t in tasks]
        self._client.write_records(_WS_BACKLOG, rows)

    def _write_allocations(self, allocations: list[Allocation]) -> None:
        rows: list[dict[str, object]] = []
        for allocation in allocations:
            rows.extend(_allocation_to_rows(allocation))
        self._client.write_records(_WS_TEAM_ALLOCATION, rows)

    def _write_report(self, report: WeeklyReport) -> None:
        rows = _report_to_rows(report)
        self._client.write_records(_WS_WEEKLY_REPORT, rows)
