"""
ReporterService

Generates a WeeklyReport from a WeeklyPlanResult.
No AI, no LLM, no fuzzy logic — pure deterministic aggregation.
"""

from collections import Counter

from app.domain import WeeklyReport
from app.services.schemas import WeeklyPlanResult


class ReporterService:
    """
    Builds a WeeklyReport from a completed WeeklyPlanResult.

    Usage::

        reporter = ReporterService()
        report = reporter.build_report(result)
    """

    def build_report(self, result: WeeklyPlanResult) -> WeeklyReport:
        total_tasks = len(result.scheduled_tasks) + len(result.backlog_tasks)
        scheduled_count = len(result.scheduled_tasks)
        backlog_count = len(result.backlog_tasks)

        utilization = self._team_utilization(result)
        top_categories = self._top_categories(result)
        summary_lines = self._build_summary_lines(result, utilization)

        return WeeklyReport(
            week_ref=result.week_ref,
            completed_tasks_count=0,          # filled by pipeline when completed sheet available
            active_tasks_count=scheduled_count,
            summary_lines=summary_lines,
        )

    # ---------------------------------------------------------------- private

    @staticmethod
    def _team_utilization(result: WeeklyPlanResult) -> dict[str, float]:
        """Return member_name → utilization_percent (0-100)."""
        capacity_index = {c.member_name: c.available_hours for c in result.team_capacity}
        alloc_index = {a.assignee: a.allocated_hours for a in result.allocations}

        utilization: dict[str, float] = {}
        for name, available in capacity_index.items():
            if available > 0:
                allocated = alloc_index.get(name, 0.0)
                utilization[name] = round(allocated / available * 100, 1)
            else:
                utilization[name] = 0.0
        return utilization

    @staticmethod
    def _top_categories(result: WeeklyPlanResult, top_n: int = 5) -> list[str]:
        """Return up to top_n task_type values by frequency in scheduled tasks."""
        counter: Counter[str] = Counter(t.task_type for t in result.scheduled_tasks)
        return [cat for cat, _ in counter.most_common(top_n)]

    @staticmethod
    def _build_summary_lines(
        result: WeeklyPlanResult,
        utilization: dict[str, float],
    ) -> list[str]:
        lines: list[str] = []

        total = len(result.scheduled_tasks) + len(result.backlog_tasks)
        lines.append(f"Всего задач: {total}")
        lines.append(f"Запланировано: {len(result.scheduled_tasks)}")
        lines.append(f"В бэклог: {len(result.backlog_tasks)}")
        lines.append(f"Плановые часы: {result.planned_hours:.1f}ч")
        lines.append(f"Ёмкость команды: {result.total_capacity_hours:.1f}ч")

        if utilization:
            avg_util = round(sum(utilization.values()) / len(utilization), 1)
            lines.append(f"Средняя загрузка: {avg_util}%")
            for name, pct in sorted(utilization.items()):
                lines.append(f"  {name}: {pct}%")

        if result.backlog_tasks:
            lines.append(f"Часы бэклога: {result.backlog_hours:.1f}ч")

        return lines
