"""
ExportService

Single public method: export(result)

Responsibilities:
1. Build WeeklyReport from WeeklyPlanResult
2. Write all four output worksheets via SheetsWriter
3. Return ExportResult

The service is the only layer that touches SheetsWriter.
Routers never call SheetsWriter directly.
"""

from dataclasses import dataclass

from app.connectors.sheets.client import GoogleSheetsClient
from app.connectors.sheets.writer import SheetsWriter
from app.domain import WeeklyReport
from app.services.reporter import ReporterService
from app.services.schemas import WeeklyPlanResult


@dataclass(frozen=True)
class ExportResult:
    success: bool
    exported: bool
    week_ref: str
    scheduled_tasks: int
    backlog_tasks: int
    error: str | None = None


class ExportService:
    """
    Orchestrates the report-build + Sheets-write cycle.

    Usage::

        service = ExportService(client)
        result = service.export(weekly_plan_result)
    """

    def __init__(self, client: GoogleSheetsClient) -> None:
        self._reporter = ReporterService()
        self._writer = SheetsWriter(client)

    def export(self, result: WeeklyPlanResult) -> ExportResult:
        """
        Generate report and write all output worksheets.

        Returns ExportResult with success=False and error message on failure.
        Does not re-raise exceptions — callers check ExportResult.success.
        """
        try:
            report: WeeklyReport = self._reporter.build_report(result)
            self._writer.write_plan_result(result, report)
            return ExportResult(
                success=True,
                exported=True,
                week_ref=result.week_ref,
                scheduled_tasks=len(result.scheduled_tasks),
                backlog_tasks=len(result.backlog_tasks),
            )
        except Exception as exc:  # noqa: BLE001
            return ExportResult(
                success=False,
                exported=False,
                week_ref=result.week_ref,
                scheduled_tasks=len(result.scheduled_tasks),
                backlog_tasks=len(result.backlog_tasks),
                error=str(exc),
            )
