import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import BacklogPage from "@/app/backlog/page";
import type { Task, WeeklyPlanResult } from "@/src/lib/api/types";

vi.mock("@/src/lib/api/plans", () => ({
  generatePlan: vi.fn(),
  exportPlan: vi.fn(),
}));

vi.mock("framer-motion", () => ({
  motion: {
    div: ({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
      <div {...props}>{children}</div>
    ),
  },
}));

import * as plansApi from "@/src/lib/api/plans";

const BACKLOG_TASK: Task = {
  task_id: "B1",
  title: "SEO аудит",
  source: "monthly",
  status: "planned",
  owner: "Борис",
  assignee: null,
  estimate_hours: 4,
  task_type: "analysis",
  week_ref: "2026-W25",
  is_completed: false,
  is_assigned: false,
};

const RESULT_WITH_BACKLOG: WeeklyPlanResult = {
  week_ref: "2026-W25",
  scheduled_tasks: [],
  backlog_tasks: [BACKLOG_TASK],
  allocations: [],
  team_capacity: [],
  total_capacity_hours: 0,
  planned_hours: 0,
  backlog_hours: 4,
};

const RESULT_EMPTY_BACKLOG: WeeklyPlanResult = {
  week_ref: "2026-W25",
  scheduled_tasks: [],
  backlog_tasks: [],
  allocations: [],
  team_capacity: [],
  total_capacity_hours: 0,
  planned_hours: 0,
  backlog_hours: 0,
};

describe("BacklogPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders idle state", () => {
    render(<BacklogPage />);
    expect(screen.getByText("Бэклог не загружен")).toBeDefined();
    expect(screen.getByText("Обновить")).toBeDefined();
  });

  it("shows loading state while fetching", async () => {
    vi.mocked(plansApi.generatePlan).mockReturnValue(new Promise(() => {}));
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Загрузка...")).toBeDefined();
    });
  });

  it("shows error state on failure", async () => {
    vi.mocked(plansApi.generatePlan).mockRejectedValue(new Error("Ошибка сети"));
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Ошибка сети")).toBeDefined();
    });
  });

  it("renders backlog tasks after load", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(RESULT_WITH_BACKLOG);
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("SEO аудит")).toBeDefined();
    });
  });

  it("shows empty backlog state when all tasks scheduled", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(RESULT_EMPTY_BACKLOG);
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Бэклог пуст")).toBeDefined();
    });
  });

  it("groups tasks by week_ref", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(RESULT_WITH_BACKLOG);
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("2026-W25")).toBeDefined();
    });
  });

  it("shows backlog hours summary", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(RESULT_WITH_BACKLOG);
    render(<BacklogPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("4ч")).toBeDefined();
    });
  });
});
