import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ReportPage from "@/app/report/page";
import type { WeeklyReport } from "@/src/lib/api/types";

vi.mock("@/src/lib/api/report", () => ({
  getCurrentReport: vi.fn(),
  getHealth: vi.fn(),
}));

vi.mock("framer-motion", () => ({
  motion: {
    div: ({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
      <div {...props}>{children}</div>
    ),
  },
}));

import * as reportApi from "@/src/lib/api/report";

const MOCK_REPORT: WeeklyReport = {
  week_ref: "2026-W25",
  completed_tasks_count: 3,
  active_tasks_count: 8,
  summary_lines: ["Всего задач: 11", "Запланировано: 8", "Средняя загрузка: 75%"],
  total_referenced_tasks_count: 11,
  has_activity: true,
};

describe("ReportPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders idle state with update button", () => {
    render(<ReportPage />);
    expect(screen.getByText("Обновить")).toBeDefined();
    expect(screen.getByText("Отчёт не загружен")).toBeDefined();
  });

  it("shows loading state while fetching", async () => {
    vi.mocked(reportApi.getCurrentReport).mockReturnValue(new Promise(() => {}));
    render(<ReportPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Загрузка...")).toBeDefined();
    });
  });

  it("shows error state on failure", async () => {
    vi.mocked(reportApi.getCurrentReport).mockRejectedValue(new Error("Sheets недоступен"));
    render(<ReportPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Sheets недоступен")).toBeDefined();
    });
  });

  it("renders report metrics after load", async () => {
    vi.mocked(reportApi.getCurrentReport).mockResolvedValue(MOCK_REPORT);
    render(<ReportPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("8")).toBeDefined(); // active_tasks_count
      expect(screen.getByText("3")).toBeDefined(); // completed_tasks_count
    });
  });

  it("renders summary lines", async () => {
    vi.mocked(reportApi.getCurrentReport).mockResolvedValue(MOCK_REPORT);
    render(<ReportPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Всего задач: 11")).toBeDefined();
      expect(screen.getByText("Средняя загрузка: 75%")).toBeDefined();
    });
  });

  it("shows week ref in header after load", async () => {
    vi.mocked(reportApi.getCurrentReport).mockResolvedValue(MOCK_REPORT);
    render(<ReportPage />);
    fireEvent.click(screen.getByText("Обновить"));
    await waitFor(() => {
      expect(screen.getByText("Неделя 2026-W25")).toBeDefined();
    });
  });
});
