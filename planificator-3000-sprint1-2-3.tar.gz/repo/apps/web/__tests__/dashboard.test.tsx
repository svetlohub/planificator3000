import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import DashboardPage from "@/app/dashboard/page";
import type { WeeklyPlanResult } from "@/src/lib/api/types";

// Mock the API module
vi.mock("@/src/lib/api/plans", () => ({
  generatePlan: vi.fn(),
  exportPlan: vi.fn(),
}));

// Mock framer-motion to avoid animation issues in tests
vi.mock("framer-motion", () => ({
  motion: {
    div: ({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
      <div {...props}>{children}</div>
    ),
  },
}));

// Mock recharts
vi.mock("recharts", () => ({
  ResponsiveContainer: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  BarChart: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Bar: () => null,
  XAxis: () => null,
  YAxis: () => null,
  CartesianGrid: () => null,
  Tooltip: () => null,
  PieChart: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Pie: () => null,
  Cell: () => null,
}));

import * as plansApi from "@/src/lib/api/plans";

const EMPTY_RESULT: WeeklyPlanResult = {
  week_ref: "2026-W25",
  scheduled_tasks: [],
  backlog_tasks: [],
  allocations: [],
  team_capacity: [],
  total_capacity_hours: 0,
  planned_hours: 0,
  backlog_hours: 0,
};

const FULL_RESULT: WeeklyPlanResult = {
  week_ref: "2026-W25",
  scheduled_tasks: [
    {
      task_id: "T1",
      title: "Тестовая задача",
      source: "monthly",
      status: "planned",
      owner: "Алиса",
      assignee: "Алиса",
      estimate_hours: 2,
      task_type: "analysis",
      week_ref: "2026-W25",
      is_completed: false,
      is_assigned: true,
    },
  ],
  backlog_tasks: [],
  allocations: [],
  team_capacity: [
    { member_name: "Алиса", total_hours: 40, buffer_hours: 10, available_hours: 30, buffer_percent: 25 },
  ],
  total_capacity_hours: 30,
  planned_hours: 2,
  backlog_hours: 0,
};

describe("DashboardPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders idle state with run button", () => {
    render(<DashboardPage />);
    expect(screen.getByText("Запустить план")).toBeDefined();
    expect(screen.getByText("Данные не загружены")).toBeDefined();
  });

  it("shows loading state when syncing", async () => {
    vi.mocked(plansApi.generatePlan).mockReturnValue(new Promise(() => {}));
    render(<DashboardPage />);
    fireEvent.click(screen.getByText("Запустить план"));
    await waitFor(() => {
      expect(screen.getByText("Генерация...")).toBeDefined();
    });
  });

  it("shows stat cards after successful load", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(FULL_RESULT);
    render(<DashboardPage />);
    fireEvent.click(screen.getByText("Запустить план"));
    await waitFor(() => {
      expect(screen.getByText("Тестовая задача")).toBeDefined();
    });
  });

  it("shows error state on API failure", async () => {
    vi.mocked(plansApi.generatePlan).mockRejectedValue(new Error("503 недоступен"));
    render(<DashboardPage />);
    fireEvent.click(screen.getByText("Запустить план"));
    await waitFor(() => {
      expect(screen.getByText("503 недоступен")).toBeDefined();
    });
  });

  it("shows export button after successful load", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(EMPTY_RESULT);
    render(<DashboardPage />);
    fireEvent.click(screen.getByText("Запустить план"));
    await waitFor(() => {
      expect(screen.getByText("→ Sheets")).toBeDefined();
    });
  });

  it("shows planned hours stat card", async () => {
    vi.mocked(plansApi.generatePlan).mockResolvedValue(FULL_RESULT);
    render(<DashboardPage />);
    fireEvent.click(screen.getByText("Запустить план"));
    await waitFor(() => {
      expect(screen.getByText("2ч")).toBeDefined();
    });
  });
});
