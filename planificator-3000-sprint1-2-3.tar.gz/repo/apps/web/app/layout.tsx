import type { Metadata } from "next";
import type { ReactNode } from "react";

import { APP_NAME } from "@planner3000/shared";
import { Sidebar } from "@/src/components/sidebar";

import "./globals.css";

export const metadata: Metadata = {
  title: APP_NAME,
  description: "From Spreadsheet Chaos to Weekly Execution",
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="ru" className="dark">
      <body className="bg-[#0f172a] text-[#f1f5f9]">
        <Sidebar />
        <main className="ml-60 min-h-screen">{children}</main>
      </body>
    </html>
  );
}
