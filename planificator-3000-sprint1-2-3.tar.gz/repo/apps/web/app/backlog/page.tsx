"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { EmptyState, ErrorState, LoadingState, Badge } from "@/src/components/ui/feedback";
import { generatePlan } from "@/src/lib/api/plans";
import type { Task, WeeklyPlanResult } from "@/src/lib/api/types";

type State = "idle" | "loading" | "success" | "error";

function groupByWeek(tasks: Task[]): Record<string, Task[]> {
  const groups: Record<string, Task[]> = {};
  for (const task of tasks) {
    if (!groups[task.week_ref]) groups[task.week_ref] = [];
    groups[task.week_ref].push(task);
  }
  return groups;
}

export default function BacklogPage() {
  const [state, setState] = useState<State>("idle");
  const [result, setResult] = useState<WeeklyPlanResult | null>(null);
  const [error, setError] = useState("");

  async function load() {
    setState("loading");
    try {
      const data = await generatePlan();
      setResult(data);
      setState("success");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка загрузки");
      setState("error");
    }
  }

  const grouped = result ? groupByWeek(result.backlog_tasks) : {};
  const weeks = Object.keys(grouped).sort();

  return (
    <div className="px-8 py-8">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black tracking-tight gradient-text">Бэклог</h1>
          <p className="mt-1 text-sm text-[var(--color-muted-foreground)]">
            {result
              ? `${result.backlog_tasks.length} задач · ${result.backlog_hours}ч`
              : "Задачи, которые не вошли в план"}
          </p>
        </div>
        <button
          onClick={load}
          disabled={state === "loading"}
          className="rounded-xl bg-[#19aef9]/10 border border-[#19aef9]/20 px-4 py-2 text-sm text-[#19aef9] hover:bg-[#19aef9]/20 transition disabled:opacity-50"
        >
          {state === "loading" ? "Загрузка..." : "Обновить"}
        </button>
      </div>

      {state === "idle" && (
        <EmptyState
          title="Бэклог не загружен"
          description="Нажмите «Обновить» чтобы увидеть задачи, не вошедшие в план."
        />
      )}
      {state === "loading" && <LoadingState />}
      {state === "error" && <ErrorState message={error} onRetry={load} />}

      {state === "success" && result && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[#ff9839]">
                {result.backlog_tasks.length}
              </div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">Задач в бэклоге</div>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[var(--color-foreground)]">
                {result.backlog_hours}ч
              </div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">Часов отложено</div>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[#a78bfa]">{weeks.length}</div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">Недель</div>
            </div>
          </div>

          {weeks.length === 0 ? (
            <EmptyState
              title="Бэклог пуст"
              description="Все задачи вошли в план. Отличная работа!"
            />
          ) : (
            weeks.map((week) => (
              <div key={week} className="glass rounded-2xl p-5">
                <div className="mb-4 flex items-center gap-3">
                  <h2 className="text-sm font-semibold">{week}</h2>
                  <Badge variant="warning">{grouped[week].length} задач</Badge>
                  <span className="text-xs text-[var(--color-muted-foreground)]">
                    {grouped[week].reduce((s, t) => s + t.estimate_hours, 0)}ч
                  </span>
                </div>
                <div className="space-y-2">
                  {grouped[week].map((task) => (
                    <div
                      key={task.task_id}
                      className="flex items-center justify-between rounded-xl border border-white/[0.05] bg-white/[0.02] px-4 py-3"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-[var(--color-foreground)]">
                          {task.title}
                        </p>
                        <p className="text-xs text-[var(--color-muted-foreground)]">
                          {task.owner} · {task.task_type} · {task.source}
                        </p>
                      </div>
                      <span className="ml-4 text-xs font-medium text-[#ff9839]">
                        {task.estimate_hours}ч
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </motion.div>
      )}
    </div>
  );
}
