"use client";

export default function DashboardError({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-8">
      <p className="text-sm text-red-400">{error.message}</p>
      <button
        onClick={reset}
        className="rounded-xl bg-[#19aef9]/10 px-4 py-2 text-sm text-[#19aef9]"
      >
        Повторить
      </button>
    </div>
  );
}
