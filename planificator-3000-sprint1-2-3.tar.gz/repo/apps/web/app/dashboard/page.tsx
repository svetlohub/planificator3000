"use client";

import { useState } from "react";
import { BarChart3, Clock, Inbox, Users, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { StatCard } from "@/src/components/ui/stat-card";
import { EmptyState, ErrorState, LoadingState } from "@/src/components/ui/feedback";
import { CapacityChart } from "@/src/components/charts/capacity-chart";
import { WorkloadChart } from "@/src/components/charts/workload-chart";
import { generatePlan, exportPlan } from "@/src/lib/api/plans";
import type { WeeklyPlanResult } from "@/src/lib/api/types";

type State = "idle" | "loading" | "success" | "error";

export default function DashboardPage() {
  const [state, setState] = useState<State>("idle");
  const [result, setResult] = useState<WeeklyPlanResult | null>(null);
  const [error, setError] = useState<string>("");
  const [exporting, setExporting] = useState(false);
  const [exportMsg, setExportMsg] = useState("");

  async function handleSync() {
    setState("loading");
    setError("");
    try {
      const data = await generatePlan();
      setResult(data);
      setState("success");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка синхронизации");
      setState("error");
    }
  }

  async function handleExport() {
    if (!result) return;
    setExporting(true);
    setExportMsg("");
    try {
      const res = await exportPlan(result.week_ref);
      setExportMsg(res.success ? "✓ Результаты записаны в Sheets" : `Ошибка: ${res.error}`);
    } catch (e) {
      setExportMsg(e instanceof Error ? e.message : "Ошибка экспорта");
    } finally {
      setExporting(false);
    }
  }

  const utilization =
    result && result.total_capacity_hours > 0
      ? Math.round((result.planned_hours / result.total_capacity_hours) * 100)
      : 0;

  return (
    <div className="px-8 py-8">
      {/* Header */}
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black tracking-tight gradient-text">Дашборд</h1>
          <p className="mt-1 text-sm text-[var(--color-muted-foreground)]">
            {result ? `Неделя ${result.week_ref}` : "Синхронизируйте данные из Google Sheets"}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {result && (
            <button
              onClick={handleExport}
              disabled={exporting}
              className="flex items-center gap-2 rounded-xl border border-[#ff9839]/30 bg-[#ff9839]/10 px-4 py-2 text-sm font-medium text-[#ff9839] transition hover:bg-[#ff9839]/20 disabled:opacity-50"
            >
              {exporting ? "Экспорт..." : "→ Sheets"}
            </button>
          )}
          <button
            onClick={handleSync}
            disabled={state === "loading"}
            className="flex items-center gap-2 rounded-xl bg-[#19aef9] px-5 py-2.5 text-sm font-semibold text-[#0f172a] transition hover:bg-[#19aef9]/90 disabled:opacity-60 glow-accent"
          >
            <Zap className="h-4 w-4" />
            {state === "loading" ? "Генерация..." : "Запустить план"}
          </button>
        </div>
      </div>

      {exportMsg && (
        <div className="mb-4 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-[var(--color-muted-foreground)]">
          {exportMsg}
        </div>
      )}

      {/* States */}
      {state === "idle" && (
        <EmptyState
          title="Данные не загружены"
          description="Нажмите «Запустить план» чтобы синхронизировать данные из Google Sheets и сгенерировать недельный план."
        />
      )}

      {state === "loading" && <LoadingState message="Загрузка и планирование..." />}

      {state === "error" && (
        <ErrorState message={error} onRetry={handleSync} />
      )}

      {state === "success" && result && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="space-y-6"
        >
          {/* Stat cards */}
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard
              label="Задачи"
              value={result.scheduled_tasks.length + result.backlog_tasks.length}
              sub={`${result.scheduled_tasks.length} запланировано`}
              icon={<BarChart3 className="h-4 w-4" />}
              accent="blue"
            />
            <StatCard
              label="Плановые часы"
              value={`${result.planned_hours}ч`}
              sub={`из ${result.total_capacity_hours}ч доступных`}
              icon={<Clock className="h-4 w-4" />}
              accent="purple"
            />
            <StatCard
              label="Загрузка"
              value={`${utilization}%`}
              sub={`${result.team_capacity.length} чел. в команде`}
              icon={<Users className="h-4 w-4" />}
              accent={utilization > 90 ? "orange" : "green"}
            />
            <StatCard
              label="Бэклог"
              value={result.backlog_tasks.length}
              sub={`${result.backlog_hours}ч отложено`}
              icon={<Inbox className="h-4 w-4" />}
              accent="orange"
            />
          </div>

          {/* Charts */}
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="glass rounded-2xl p-5">
              <h2 className="mb-4 text-sm font-semibold text-[var(--color-foreground)]">
                Загрузка команды
              </h2>
              <CapacityChart
                capacities={result.team_capacity}
                allocations={result.allocations}
              />
            </div>
            <div className="glass rounded-2xl p-5">
              <h2 className="mb-4 text-sm font-semibold text-[var(--color-foreground)]">
                Распределение по типам
              </h2>
              <WorkloadChart tasks={result.scheduled_tasks} />
            </div>
          </div>

          {/* Scheduled tasks */}
          <div className="glass rounded-2xl p-5">
            <h2 className="mb-4 text-sm font-semibold text-[var(--color-foreground)]">
              Запланированные задачи ({result.scheduled_tasks.length})
            </h2>
            {result.scheduled_tasks.length === 0 ? (
              <p className="text-sm text-[var(--color-muted-foreground)]">Нет задач</p>
            ) : (
              <div className="space-y-2">
                {result.scheduled_tasks.map((t) => (
                  <div
                    key={t.task_id}
                    className="flex items-center justify-between rounded-xl border border-white/[0.05] bg-white/[0.02] px-4 py-2.5"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-[var(--color-foreground)]">
                        {t.title}
                      </p>
                      <p className="text-xs text-[var(--color-muted-foreground)]">
                        {t.assignee ?? t.owner} · {t.task_type}
                      </p>
                    </div>
                    <span className="ml-4 text-xs font-medium text-[#19aef9]">
                      {t.estimate_hours}ч
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}
