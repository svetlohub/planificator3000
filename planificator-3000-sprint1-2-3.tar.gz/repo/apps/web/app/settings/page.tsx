"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { LoadingState, ErrorState, Badge } from "@/src/components/ui/feedback";
import { getHealth } from "@/src/lib/api/report";
import type { HealthResponse } from "@/src/lib/api/types";

export default function SettingsPage() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHealth()
      .then(setHealth)
      .catch((e) => setError(e instanceof Error ? e.message : "Ошибка"))
      .finally(() => setLoading(false));
  }, []);

  const apiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

  return (
    <div className="px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-black tracking-tight gradient-text">Настройки</h1>
        <p className="mt-1 text-sm text-[var(--color-muted-foreground)]">
          Статус подключения и конфигурация (только чтение)
        </p>
      </div>

      {loading && <LoadingState message="Проверка соединения..." />}
      {error && <ErrorState message={error} />}

      {!loading && health && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-lg space-y-4"
        >
          {/* API Status */}
          <div className="glass rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-semibold">API</h2>
            <Row label="URL" value={apiUrl} />
            <Row label="Сервис" value={health.service} />
            <Row label="Окружение" value={health.environment} />
            <Row
              label="Статус"
              value={
                <Badge variant="success">
                  {health.status}
                </Badge>
              }
            />
          </div>

          {/* Sheets Status */}
          <div className="glass rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-semibold">Google Sheets</h2>
            <Row
              label="Настроен"
              value={
                <Badge variant={health.sheets_configured ? "success" : "warning"}>
                  {health.sheets_configured ? "Да" : "Нет"}
                </Badge>
              }
            />
            <Row
              label="Соединение"
              value={
                health.sheets_healthy === null ? (
                  <Badge variant="default">Нет данных</Badge>
                ) : (
                  <Badge variant={health.sheets_healthy ? "success" : "error"}>
                    {health.sheets_healthy ? "OK" : "Ошибка"}
                  </Badge>
                )
              }
            />
          </div>

          {/* Instructions */}
          {!health.sheets_configured && (
            <div className="rounded-2xl border border-[#ff9839]/20 bg-[#ff9839]/5 p-5">
              <p className="text-sm font-medium text-[#ff9839] mb-2">Требуется настройка</p>
              <p className="text-xs text-[var(--color-muted-foreground)] leading-5">
                Задайте переменные окружения на сервере:
                <br />
                <code className="text-[#19aef9]">GOOGLE_SHEET_ID</code> — ID вашей таблицы
                <br />
                <code className="text-[#19aef9]">GOOGLE_SERVICE_ACCOUNT_JSON</code> — JSON сервисного аккаунта
              </p>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-[var(--color-muted-foreground)]">{label}</span>
      <span className="text-sm font-medium text-[var(--color-foreground)]">{value}</span>
    </div>
  );
}
