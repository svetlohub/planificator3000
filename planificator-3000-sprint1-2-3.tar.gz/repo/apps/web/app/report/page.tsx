"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { EmptyState, ErrorState, LoadingState } from "@/src/components/ui/feedback";
import { getCurrentReport } from "@/src/lib/api/report";
import type { WeeklyReport } from "@/src/lib/api/types";

type State = "idle" | "loading" | "success" | "error";

export default function ReportPage() {
  const [state, setState] = useState<State>("idle");
  const [report, setReport] = useState<WeeklyReport | null>(null);
  const [error, setError] = useState("");

  async function load() {
    setState("loading");
    try {
      const data = await getCurrentReport();
      setReport(data);
      setState("success");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка загрузки");
      setState("error");
    }
  }

  return (
    <div className="px-8 py-8">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black tracking-tight gradient-text">Еженедельный отчёт</h1>
          <p className="mt-1 text-sm text-[var(--color-muted-foreground)]">
            {report ? `Неделя ${report.week_ref}` : "Отчёт по результатам планирования"}
          </p>
        </div>
        <button
          onClick={load}
          disabled={state === "loading"}
          className="rounded-xl bg-[#19aef9]/10 border border-[#19aef9]/20 px-4 py-2 text-sm text-[#19aef9] hover:bg-[#19aef9]/20 transition disabled:opacity-50"
        >
          {state === "loading" ? "Загрузка..." : "Обновить"}
        </button>
      </div>

      {state === "idle" && (
        <EmptyState title="Отчёт не загружен" description="Нажмите «Обновить» чтобы сгенерировать отчёт." />
      )}
      {state === "loading" && <LoadingState />}
      {state === "error" && <ErrorState message={error} onRetry={load} />}

      {state === "success" && report && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 max-w-2xl"
        >
          {/* Metrics */}
          <div className="grid grid-cols-3 gap-4">
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[#19aef9]">{report.active_tasks_count}</div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">В работе</div>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[#22c55e]">{report.completed_tasks_count}</div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">Выполнено</div>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <div className="text-2xl font-black text-[var(--color-foreground)]">
                {report.total_referenced_tasks_count}
              </div>
              <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">Всего</div>
            </div>
          </div>

          {/* Summary lines */}
          <div className="glass rounded-2xl p-5">
            <h2 className="mb-4 text-sm font-semibold">Сводка</h2>
            <ul className="space-y-2">
              {report.summary_lines.map((line, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#19aef9]" />
                  <span className="text-[var(--color-muted-foreground)]">{line}</span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      )}
    </div>
  );
}
