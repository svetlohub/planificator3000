"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { EmptyState, ErrorState, LoadingState } from "@/src/components/ui/feedback";
import { DataTable, type Column } from "@/src/components/ui/data-table";
import { Badge } from "@/src/components/ui/feedback";
import { generatePlan } from "@/src/lib/api/plans";
import type { Allocation, Capacity, WeeklyPlanResult } from "@/src/lib/api/types";

type State = "idle" | "loading" | "success" | "error";

interface TeamRow {
  name: string;
  capacity: number;
  allocated: number;
  remaining: number;
  utilization: number;
  tasks: number;
}

const columns: Column<TeamRow>[] = [
  { key: "name", header: "Сотрудник", cell: (r) => <span className="font-medium">{r.name}</span> },
  { key: "capacity", header: "Доступно", cell: (r) => `${r.capacity}ч` },
  {
    key: "allocated",
    header: "Занято",
    cell: (r) => <span className="text-[#19aef9]">{r.allocated}ч</span>,
  },
  {
    key: "remaining",
    header: "Остаток",
    cell: (r) => <span className="text-[#22c55e]">{r.remaining}ч</span>,
  },
  {
    key: "utilization",
    header: "Загрузка",
    cell: (r) => (
      <Badge variant={r.utilization > 90 ? "warning" : r.utilization > 60 ? "info" : "success"}>
        {r.utilization}%
      </Badge>
    ),
  },
  { key: "tasks", header: "Задач", cell: (r) => r.tasks },
];

export default function TeamPage() {
  const [state, setState] = useState<State>("idle");
  const [result, setResult] = useState<WeeklyPlanResult | null>(null);
  const [error, setError] = useState("");

  async function load() {
    setState("loading");
    try {
      const data = await generatePlan();
      setResult(data);
      setState("success");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка загрузки");
      setState("error");
    }
  }

  const rows: TeamRow[] = result
    ? result.team_capacity.map((cap) => {
        const alloc = result.allocations.find((a) => a.assignee === cap.member_name);
        const allocated = alloc?.allocated_hours ?? 0;
        const remaining = Math.max(0, cap.available_hours - allocated);
        const utilization =
          cap.available_hours > 0 ? Math.round((allocated / cap.available_hours) * 100) : 0;
        return {
          name: cap.member_name,
          capacity: cap.available_hours,
          allocated: Math.round(allocated * 10) / 10,
          remaining: Math.round(remaining * 10) / 10,
          utilization,
          tasks: alloc?.tasks_count ?? 0,
        };
      })
    : [];

  return (
    <div className="px-8 py-8">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black tracking-tight gradient-text">Команда</h1>
          <p className="mt-1 text-sm text-[var(--color-muted-foreground)]">Загрузка и аллокации</p>
        </div>
        <button
          onClick={load}
          disabled={state === "loading"}
          className="rounded-xl bg-[#19aef9]/10 border border-[#19aef9]/20 px-4 py-2 text-sm text-[#19aef9] hover:bg-[#19aef9]/20 transition disabled:opacity-50"
        >
          {state === "loading" ? "Загрузка..." : "Обновить"}
        </button>
      </div>

      {state === "idle" && <EmptyState title="Данные не загружены" description="Нажмите «Обновить»." />}
      {state === "loading" && <LoadingState />}
      {state === "error" && <ErrorState message={error} onRetry={load} />}

      {state === "success" && result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {rows.length === 0 ? (
            <EmptyState title="Команда пуста" description="Добавьте сотрудников в лист «Team Roster»." />
          ) : (
            <DataTable columns={columns} data={rows} rowKey={(r) => r.name} />
          )}

          {/* Per-person task breakdown */}
          {result.allocations.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold">Задачи по сотрудникам</h2>
              {result.allocations.map((alloc) => (
                <div key={alloc.assignee} className="glass rounded-2xl p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="font-medium">{alloc.assignee}</span>
                    <span className="text-xs text-[#19aef9]">
                      {alloc.allocated_hours}ч · {alloc.tasks_count} задач
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {alloc.tasks.map((t) => (
                      <div
                        key={t.task_id}
                        className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2"
                      >
                        <span className="text-sm text-[var(--color-muted-foreground)] truncate flex-1">
                          {t.title}
                        </span>
                        <span className="ml-3 text-xs text-[#19aef9]">{t.estimate_hours}ч</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}
