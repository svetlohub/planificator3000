import type { ReactNode } from "react";
import { cn } from "./utils";

// ─────────────────────────────── Badge

type BadgeVariant = "default" | "success" | "warning" | "error" | "info";

const badgeStyles: Record<BadgeVariant, string> = {
  default: "bg-white/10 text-white/70",
  success: "bg-[#22c55e]/15 text-[#22c55e]",
  warning: "bg-[#ff9839]/15 text-[#ff9839]",
  error: "bg-red-500/15 text-red-400",
  info: "bg-[#19aef9]/15 text-[#19aef9]",
};

interface BadgeProps {
  children: ReactNode;
  variant?: BadgeVariant;
  className?: string;
}

export function Badge({ children, variant = "default", className }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        badgeStyles[variant],
        className,
      )}
    >
      {children}
    </span>
  );
}

// ─────────────────────────────── LoadingState

interface LoadingStateProps {
  message?: string;
  className?: string;
}

export function LoadingState({ message = "Загрузка...", className }: LoadingStateProps) {
  return (
    <div className={cn("flex flex-col items-center justify-center gap-4 py-20", className)}>
      <div className="relative h-10 w-10">
        <div className="absolute inset-0 rounded-full border-2 border-[#19aef9]/20" />
        <div className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-[#19aef9]" />
      </div>
      <span className="text-sm text-[var(--color-muted-foreground)]">{message}</span>
    </div>
  );
}

// ─────────────────────────────── EmptyState

interface EmptyStateProps {
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({ title, description, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        "glass rounded-2xl flex flex-col items-center justify-center gap-3 py-16 px-8 text-center",
        className,
      )}
    >
      <div className="text-4xl opacity-30">○</div>
      <h3 className="text-base font-semibold text-[var(--color-foreground)]">{title}</h3>
      {description && (
        <p className="text-sm text-[var(--color-muted-foreground)] max-w-sm">{description}</p>
      )}
      {action}
    </div>
  );
}

// ─────────────────────────────── ErrorState

interface ErrorStateProps {
  message: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({ message, onRetry, className }: ErrorStateProps) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-red-500/20 bg-red-500/5 flex flex-col items-center gap-3 py-12 px-8 text-center",
        className,
      )}
    >
      <div className="text-2xl text-red-400">⚠</div>
      <p className="text-sm text-red-400">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-1 text-xs text-[#19aef9] underline underline-offset-2 hover:no-underline"
        >
          Повторить
        </button>
      )}
    </div>
  );
}
