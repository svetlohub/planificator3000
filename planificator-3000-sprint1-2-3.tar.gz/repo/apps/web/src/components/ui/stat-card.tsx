import type { ReactNode } from "react";
import { cn } from "./utils";

interface StatCardProps {
  label: string;
  value: string | number;
  sub?: string;
  icon?: ReactNode;
  accent?: "blue" | "orange" | "green" | "purple";
  className?: string;
}

const accentStyles = {
  blue: "border-[#19aef9]/20 [--glow:#19aef9]",
  orange: "border-[#ff9839]/20 [--glow:#ff9839]",
  green: "border-[#22c55e]/20 [--glow:#22c55e]",
  purple: "border-[#a78bfa]/20 [--glow:#a78bfa]",
};

export function StatCard({ label, value, sub, icon, accent = "blue", className }: StatCardProps) {
  return (
    <div
      className={cn(
        "glass rounded-2xl p-5 flex flex-col gap-3 border transition-all hover:bg-white/[0.06]",
        accentStyles[accent],
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium tracking-wider text-[var(--color-muted-foreground)] uppercase">
          {label}
        </span>
        {icon && <span className="text-[var(--glow)] opacity-70">{icon}</span>}
      </div>
      <span className="text-3xl font-black tracking-tight text-[var(--color-foreground)]">
        {value}
      </span>
      {sub && <span className="text-xs text-[var(--color-muted-foreground)]">{sub}</span>}
    </div>
  );
}
