"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, CheckSquare, LayoutDashboard, List, Settings, Zap } from "lucide-react";
import { cn } from "@/src/components/ui/utils";

const NAV = [
  { href: "/dashboard", label: "Дашборд", icon: LayoutDashboard },
  { href: "/report", label: "Отчёт", icon: BarChart3 },
  { href: "/team", label: "Команда", icon: CheckSquare },
  { href: "/backlog", label: "Бэклог", icon: List },
  { href: "/settings", label: "Настройки", icon: Settings },
];

export function Sidebar() {
  const path = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-full w-60 glass-strong border-r border-white/[0.06] flex flex-col z-40">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-white/[0.06]">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#19aef9]/15">
            <Zap className="h-4 w-4 text-[#19aef9]" />
          </div>
          <div>
            <div className="text-sm font-black tracking-tight text-white">PLANIFICATOR</div>
            <div className="text-[10px] text-[var(--color-muted-foreground)] tracking-widest">-3000-</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = path.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all",
                active
                  ? "bg-[#19aef9]/10 text-[#19aef9] font-medium"
                  : "text-[var(--color-muted-foreground)] hover:bg-white/[0.05] hover:text-white",
              )}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-white/[0.06]">
        <p className="text-[10px] text-[var(--color-muted-foreground)] leading-4">
          From Spreadsheet Chaos
          <br />
          to Weekly Execution
        </p>
      </div>
    </aside>
  );
}
