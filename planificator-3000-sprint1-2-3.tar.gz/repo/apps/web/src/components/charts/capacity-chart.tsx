"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Allocation, Capacity } from "@/src/lib/api/types";

interface CapacityChartProps {
  capacities: Capacity[];
  allocations: Allocation[];
}

interface ChartEntry {
  name: string;
  allocated: number;
  remaining: number;
  available: number;
  utilization: number;
}

export function CapacityChart({ capacities, allocations }: CapacityChartProps) {
  const allocByMember = Object.fromEntries(allocations.map((a) => [a.assignee, a.allocated_hours]));

  const data: ChartEntry[] = capacities.map((cap) => {
    const allocated = allocByMember[cap.member_name] ?? 0;
    const remaining = Math.max(0, cap.available_hours - allocated);
    const utilization = cap.available_hours > 0 ? Math.round((allocated / cap.available_hours) * 100) : 0;
    return {
      name: cap.member_name,
      allocated: Math.round(allocated * 10) / 10,
      remaining: Math.round(remaining * 10) / 10,
      available: cap.available_hours,
      utilization,
    };
  });

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-sm text-[var(--color-muted-foreground)]">
        Нет данных о команде
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} barSize={28} margin={{ left: -10, right: 10 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 11, fill: "#94a3b8" }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 11, fill: "#94a3b8" }}
          axisLine={false}
          tickLine={false}
          unit="ч"
        />
        <Tooltip
          contentStyle={{
            background: "#1e293b",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "12px",
            color: "#f1f5f9",
            fontSize: "12px",
          }}
          formatter={(value: number, name: string) => [
            `${value}ч`,
            name === "allocated" ? "Занято" : "Свободно",
          ]}
        />
        <Bar dataKey="allocated" stackId="a" fill="#19aef9" radius={[0, 0, 0, 0]} name="allocated" />
        <Bar dataKey="remaining" stackId="a" fill="rgba(255,255,255,0.08)" radius={[6, 6, 0, 0]} name="remaining" />
      </BarChart>
    </ResponsiveContainer>
  );
}
