"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { Task } from "@/src/lib/api/types";

const COLORS = ["#19aef9", "#a78bfa", "#ff9839", "#22c55e", "#f472b6", "#34d399"];

interface WorkloadChartProps {
  tasks: Task[];
}

export function WorkloadChart({ tasks }: WorkloadChartProps) {
  const byType: Record<string, number> = {};
  for (const task of tasks) {
    byType[task.task_type] = (byType[task.task_type] ?? 0) + task.estimate_hours;
  }

  const data = Object.entries(byType)
    .map(([name, hours]) => ({ name, value: Math.round(hours * 10) / 10 }))
    .sort((a, b) => b.value - a.value);

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-sm text-[var(--color-muted-foreground)]">
        Нет задач
      </div>
    );
  }

  return (
    <div className="flex items-center gap-6">
      <ResponsiveContainer width={160} height={160}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            cx="50%"
            cy="50%"
            innerRadius={45}
            outerRadius={72}
            strokeWidth={0}
          >
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              background: "#1e293b",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "12px",
              color: "#f1f5f9",
              fontSize: "12px",
            }}
            formatter={(v: number) => [`${v}ч`, ""]}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="flex flex-col gap-2 flex-1 min-w-0">
        {data.map((entry, i) => (
          <div key={entry.name} className="flex items-center gap-2">
            <span
              className="h-2 w-2 rounded-full flex-shrink-0"
              style={{ background: COLORS[i % COLORS.length] }}
            />
            <span className="text-xs text-[var(--color-muted-foreground)] truncate flex-1">
              {entry.name}
            </span>
            <span className="text-xs font-medium text-[var(--color-foreground)]">
              {entry.value}ч
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
