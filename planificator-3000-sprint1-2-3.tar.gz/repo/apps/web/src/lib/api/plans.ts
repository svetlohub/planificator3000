import { apiFetch } from "./client";
import type { CurrentPlanResponse, ExportResponse, WeeklyPlanResult } from "./types";

export function generatePlan(weekRef: string = "2026-W25"): Promise<WeeklyPlanResult> {
  return apiFetch<WeeklyPlanResult>(`/plans/generate?week_ref=${weekRef}`);
}

export function getCurrentPlan(): Promise<CurrentPlanResponse> {
  return apiFetch<CurrentPlanResponse>("/plans/current");
}

export function exportPlan(weekRef: string = "2026-W25"): Promise<ExportResponse> {
  return apiFetch<ExportResponse>(`/plans/export?week_ref=${weekRef}`, { method: "POST" });
}
