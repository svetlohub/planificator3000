import { apiFetch } from "./client";
import type { HealthResponse, WeeklyReport } from "./types";

export function getCurrentReport(weekRef: string = "2026-W25"): Promise<WeeklyReport> {
  return apiFetch<WeeklyReport>(`/report/current?week_ref=${weekRef}`);
}

export function getHealth(): Promise<HealthResponse> {
  return apiFetch<HealthResponse>("/health");
}
