// ─────────────────────────────────────────────────────────────────────────────
// API contracts — manually maintained to match FastAPI response models.
// These types mirror the Pydantic schemas in apps/api/app/services/schemas.py
// and apps/api/app/domain/*.py exactly.
// ─────────────────────────────────────────────────────────────────────────────

export type TaskSource = "completed" | "monthly" | "recurring" | "carry_over";
export type TaskStatus = "done" | "pending" | "planned" | "in_progress";

export interface Task {
  task_id: string;
  title: string;
  source: TaskSource;
  status: TaskStatus;
  owner: string;
  assignee: string | null;
  estimate_hours: number;
  task_type: string;
  week_ref: string;
  is_completed: boolean;
  is_assigned: boolean;
}

export interface TeamMember {
  name: string;
  weekly_capacity_hours: number;
  reserved_buffer_percent: number;
  skills: string[];
  buffer_hours: number;
  available_capacity_hours: number;
}

export interface Capacity {
  member_name: string;
  total_hours: number;
  buffer_hours: number;
  available_hours: number;
  buffer_percent: number;
}

export interface Allocation {
  assignee: string;
  tasks: Task[];
  allocated_hours: number;
  tasks_count: number;
}

export interface WeeklyPlanResult {
  week_ref: string;
  scheduled_tasks: Task[];
  backlog_tasks: Task[];
  allocations: Allocation[];
  team_capacity: Capacity[];
  total_capacity_hours: number;
  planned_hours: number;
  backlog_hours: number;
}

export interface WeeklyReport {
  week_ref: string;
  completed_tasks_count: number;
  active_tasks_count: number;
  summary_lines: string[];
  total_referenced_tasks_count: number;
  has_activity: boolean;
}

export interface CurrentPlanResponse {
  tasks: Task[];
  team: TeamMember[];
  sheets_configured: boolean;
}

export interface ExportResponse {
  success: boolean;
  exported: boolean;
  week_ref: string;
  scheduled_tasks: number;
  backlog_tasks: number;
  error: string | null;
}

export interface HealthResponse {
  status: "ok";
  service: string;
  environment: string;
  sheets_configured: boolean;
  sheets_healthy: boolean | null;
}
